package com.example.Stock;
public class Stock {
    private final int stock_id;
    private final String name;
    private final String price;
    private final String quantity;

    public Stock(final int stock_id, final String name, final String price, final String quantity) {
        this.stock_id = stock_id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public int getStock_id() {
        return stock_id;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }
    public String getQuantity()
    {
        return quantity;
    }
}