package com.example.Stock;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Arrays;
import java.util.List;
@RequestMapping("/stocks")
@RestController
public class StockController {
    private final List<Stock> stocks = Arrays.asList(
            new Stock(1, "Stock A", "500", "5000"),
            new Stock(2, "Stock B", "600", "6000"),
            new Stock(3, "Stock C", "700", "10000"),
            new Stock(4, "Stock D", "800", "15000"),
            new Stock(5, "Stock E", "900", "15800"));

    @GetMapping
    public List<Stock> getAllStock() {
        return stocks;
    }

    @GetMapping("/{id}")
    public Stock getStockById(@PathVariable int id) {
        return stocks.stream()
                     .filter(order -> order.getStock_id() == id)
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
}