package com.example.Holder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HolderApplication {

	public static void main(String[] args) {
		SpringApplication.run(HolderApplication.class, args);
	}

}
