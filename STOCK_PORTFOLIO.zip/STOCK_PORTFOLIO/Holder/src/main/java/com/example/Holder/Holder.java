package com.example.Holder;
public class Holder {
    private final int reg_number;
    private final String name;
    private final String value;
    private final String country;
    private final String quantity;

    public Holder(final int reg_number,  final String name, final String value, final String country, final String quantity) {
        this.reg_number = reg_number;
        this.name = name;
        this.value = value;
        this.country = country;
        this.quantity = quantity;
    }

    public int getReg_number() {
        return reg_number;
    }

    public String getName() {
        return name;
    }
    public String getValue()
    {
        return value;
    }
    public String getCountry()
    {
        return country;
    }
    public String getQuantity()
    {
        return quantity;
    }
}