package com.example.Holder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/holders")
@RestController
public class HolderController {
    private List<Holder> holders = Arrays.asList(
            new Holder(1, "anup", "500", "IND", "2000"),
            new Holder(2, "nikhil", "250", "IND", "1000"),
            new Holder(3, "kaushik", "600", "IND", "3000"));
    
    @GetMapping
    public List<Holder> getAllHolders() {
        return holders;
    }
    
    @GetMapping("/{id}")
    public Holder getHolderById(@PathVariable int id) {
        return holders.stream()
                        .filter(holder -> holder.getReg_number() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}